#' pvector_scMASigPro
#'
#' @name scMaSigPro_t_fit
#' @aliases scMaSigPro_t_fit
#'
#' @param scMaSigPro.obj Description of Slot
#' @param Q Description of Slot
#' @param dist.family Description of Slot
#' @param assay.name Description of Slot
#' @param ep Epsilon
#' @param method Step-bacl
#' @param nb.k Dispersion factor negative binomial
#'
# Define a function named scMaSigPro_t_fit
# The function takes in several parameters which includes a single-cell MaSigPro object, a Q value (default is 0.05),
# the distribution family (default is "nb"), assay name (default is "counts"), an epsilon value (default is 0.00001),
# the method (default is "stepback"), and a negative binomial dispersion factor (default is 1)

scMaSigPro_t_fit <- function(scMaSigPro.obj,
                             Q = 0.05,
                             dist.family = "nb",
                             assay.name = "counts",
                             ep = 0.00001,
                             method = "stepback",
                             nb.k = 1) {
  # Vector of accepted distribution families
  accpt.fam <- c("g", "nb", "zinb", "p", "zip", "zap", "zanb", "gp", "gnb")

  # Function to count non-NA values
  count.na <- function(x) (length(x) - length(x[is.na(x)]))

  # Check if the provided family is in the accepted families vector, if not, stop the function
  if (!is.element(dist.family, accpt.fam)) {
    stop("Please select one of the accepted family")
  }

  # Set the distribution family to negative binomial if "nb" is provided
  if (dist.family == "nb") {
    dist <- negative.binomial(nb.k)
  }

  # Set seed for reproducibility
  set.seed(2022)

  # Identify significant genes based on adjusted p-value
  sig.genes <- names(scMaSigPro.obj@pVector@adj.p.value[scMaSigPro.obj@pVector@adj.p.value <= Q])

  # Get models associated with significant genes
  sig.full.models.list <- scMaSigPro.obj@pVector@full.models[sig.genes]
  sig.intercept.models.list <- scMaSigPro.obj@pVector@intercept.models[sig.genes]
  sig.models.list <- mapply(
    function(x, y) {
      list("full.models" = x, "intercept.models" = y)
    },
    sig.full.models.list, sig.intercept.models.list,
    SIMPLIFY = FALSE
  )

  # Apply a function to each significant gene model
  sig_covars_list <- lapply(sig.models.list, function(gene.model.i, USE.NAMES = TRUE, dist_fam = dist, epsilon = ep) {
    # Extract the Intercept Model and Full Model
    intercept.model <- gene.model.i[["intercept.models"]]
    full.model <- gene.model.i[["full.models"]]

    # Obtain a summary of the full model fit
    model.i.fit.sum <- summary(full.model)

    # Get the maximum p-value of the covariates
    covariate_i_max_pvalue <- max(model.i.fit.sum$coefficients[, 4][-1], na.rm = TRUE)

    # Create dataset for loop
    covariate.i.data.loop <- model.frame(full.model)
    colnames(covariate.i.data.loop) <- c("y", colnames(covariate.i.data.loop)[-1])

    # Begin loop if maximum p-value is above threshold Q
    if (covariate_i_max_pvalue >= Q) {
      while (covariate_i_max_pvalue >= Q) {
        # Identify the covariate with the maximum p-value
        covariate.table <- as.data.frame(model.i.fit.sum$coefficients)
        irrelevant.covariate <- rownames(covariate.table[covariate.table[["Pr(>|t|)"]] == covariate_i_max_pvalue, , drop = F])

        # Remove the identified covariate from the dataset
        covariate.i.data.loop <- covariate.i.data.loop[, !(colnames(covariate.i.data.loop) == irrelevant.covariate[1]), drop = F]

        # Check if there are still covariates in the model
        if (ncol(covariate.i.data.loop) >= 1) {
          # Refit the model without the removed covariate
          model.fit <- glm(y ~ .,
            data = covariate.i.data.loop,
            family = dist_fam, epsilon = ep
          )

          model.i.fit.sum <- summary(model.fit)
          pval.vec <- model.i.fit.sum$coefficients[, 4][-1]

          if (all(is.na(pval.vec))) {
            covariate_i_max_pvalue <- model.i.fit.sum$coefficients[, 4]
          } else {
            # Get new maximum p-value
            covariate_i_max_pvalue <- max(pval.vec, na.rm = TRUE)
          }
        } else if (ncol(covariate.i.data.loop) == 0) {
          # If no covariates are left fit the intercept-only model
          model.fit <- glm(y ~ 1,
            data = covariate.i.data.loop,
            family = dist_fam, epsilon = ep
          )
          covariate_i_max_pvalue <- 0
        }
      }

      return(list(
        full.models = full.model,
        intercept.models = intercept.model,
        covar.models = model.fit
      ))
    } else {
      return(list(
        full.models = full.model,
        intercept.models = intercept.model,
        covar.models = full.model
      ))
    }
  })


  # Extract the coefficents and P-values
  sig_measures_list <- lapply(sig_covars_list, function(gene.sig.model.i, USE.NAMES = TRUE, dist_fam = dist, epsilon = ep) {
    # Extract Models
    covar.model <- gene.sig.model.i[["covar.models"]]
    covar.model.sum <- summary(covar.model)

    # Convert to Summary Object and Extract Coefficients
    model.sum <- as.data.frame(covar.model.sum[["coefficients"]])

    # Add Rownames as column
    model.sum$covariate.name <- rownames(model.sum)

    # Compute Variance/ Goodness of fit
    g.fit <- (covar.model$null.deviance - covar.model$deviance) / covar.model$null.deviance

    # Maybe-Irrelevant
    if (g.fit < 0) {
      g.fit <- 0
    }

    # Add R2
    model.sum$model.r.square <- as.numeric(g.fit)

    # Create dataset for loop
    covar.data <- as.data.frame(model.frame(covar.model))
    colnames(covar.data) <- c("y", colnames(covar.data)[-1])

    # New Intercept Model
    intercept.model <- glm(y ~ 1, data = covar.data, family = dist_fam, epsilon = ep)
    covar.model.tmp <- glm(y ~ ., data = covar.data, family = dist_fam, epsilon = ep)

    # Anova-Chi-Square; "Pr(>Chi)" index is 4
    annova.chisq <- anova(intercept.model,
      covar.model.tmp,
      test = "Chisq"
    )

    # Add Over-all p.value
    model.sum$model.p.value <- as.numeric(annova.chisq[5][2, 1])

    # Rename Columns
    colnames(model.sum) <- c(
      "covariate.coefficient",
      "covariate.std.error",
      "covariate.t.value",
      "covariate.p.value",
      "covariate.name",
      "model.r.square",
      "model.p.value"
    )

    # Extract Covariate
    covariate.vector <- scMaSigPro.obj@covariate@covariate.vector

    # Find Missing Covariate, except the intercept
    signifi.covariates <- model.sum[["covariate.name"]][-1]
    nonsignifi.covariates <- c(
      setdiff(covariate.vector, signifi.covariates)
    )

    if (length(nonsignifi.covariates) > 0) {
      # Create an empty dataframe of nonsignifi.covariates
      nonsignifi.covariates.df <- data.frame(matrix(NA,
        nrow = length(nonsignifi.covariates),
        ncol = ncol(model.sum)
      ))

      # Transfer Column Names
      colnames(nonsignifi.covariates.df) <- colnames(model.sum)

      # Transfer avaibale Information
      nonsignifi.covariates.df[["covariate.name"]] <- nonsignifi.covariates
      nonsignifi.covariates.df[["covariate.coefficient"]] <- as.numeric(0)
      nonsignifi.covariates.df[["covariate.t.value"]] <- as.numeric(NA)

      # Combine the tables
      model.sum <- rbind(model.sum, nonsignifi.covariates.df)
    }

    # Order According to group vector
    # model.sum <- model.sum[model.sum[["covariate.name"]] %in%  c("(Intercept)", covariate.vector), ]
    model.sum <- model.sum[match(c("(Intercept)", covariate.vector), model.sum[["covariate.name"]]), ]

    # Clean Rownames and (Intercept)
    rownames(model.sum) <- NULL
    model.sum[["covariate.name"]] <- c("beta_0", paste("beta", model.sum[["covariate.name"]][-1], sep = "_"))

    return(model.sum)

  })

  # Extract Group vectors
  group.list <- lapply(sig_measures_list, function(coeff.i, path){
      group_vec <- extract.group.components(
          coeff.i, groups = c(
              colnames(scMaSigPro.obj@covariate@factor.design))
          )
      return(group_vec)
  })

  tFit.obj <- new("tFitClass",
    covar.models = sig_covars_list,
    coeff.list = sig_measures_list,
    group.list =group.list
  )

  # Add to MaSigPro Object
  scMaSigPro.obj@tFit <- tFit.obj

  return(scMaSigPro.obj)
}
