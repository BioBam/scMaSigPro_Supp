#' scMaSigProClass
#' @name scMaSigProClass
#' @aliases scMaSigProClass
#' @slot covariate Description of Slot.
#' @slot parameters Description of Slot.
#' @exportClass scMaSigProClass
#'

# Object for MaSigPro
setClass("scMaSigProCovariateClass",
  slots = c(
    factor.design = "matrix",
    time.series = "numeric",
    covariate = "matrix",
    covariate.vector = "character",
    group.vector = "character"
  )
)

# scMaSigProParameterClass
setClass("scMaSigProParameterClass",
  slots = c(
    path.col = "character",
    time.col = "character",
    poly.order = "integer",
    sig.level = "numeric"
  )
)

# pVectorClass
setClass("pVectorClass",
  slots = c(
    full.models = "list",
    intercept.models = "list",
    test.res = "list",
    p.value = "numeric",
    adj.p.value = "numeric"
  )
)

# T.fitClass
setClass("tFitClass",
  slots = c(
    covar.models = "list",
    coeff.list = "list",
    group.list = "list"
  )
)

# scMaSigProClass
setClass("scMaSigProClass",
  contains = c("SingleCellExperiment"),
  slots = c(
    covariate = "scMaSigProCovariateClass",
    parameters = "scMaSigProParameterClass",
    pVector = "pVectorClass",
    tFit = "tFitClass"
  )
)
