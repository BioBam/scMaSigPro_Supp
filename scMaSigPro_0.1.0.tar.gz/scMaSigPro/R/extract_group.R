extract.group.components <- function(extracted.model.components, coeff.col = "covariate.coefficient", groups){

    # Extract A
    A <- extracted.model.components[[coeff.col]][c(T,F)]

    # Extract B
    B <- A + extracted.model.components[[coeff.col]][c(F,T)]

    # Names
    names(A) <- paste(groups[1], "beta", c(0:(length(A)-1)), sep = "_")
    names(B) <- paste(groups[2], "beta", c(0:(length(B)-1)), sep = "_")

    # Cbind
    group.coeff <- c(A, B)

    # Return
    return(group.coeff)

}
