# Function to compute models with stat-glm per gene
#compute_stat_glm_test <- function(dist_family, gene.i.count, cov_dis, ep, nb_k) {
compute_stat_glm <- function(dist_family, gene.i.count, cov_dis, ep, nb_k) {
  if (dist_family == "nb") {
    dist <- negative.binomial(nb_k)
  } else if (dist_family == "g") {
    dist <- gaussian()
  } else if (dist_family == "p") {
    dist <- poisson()
  } else {
    stop("Please Select one of the avaible distribution")
  }

  # Compute full model
  model.glm <- glm(gene.i.count ~ ., # Formula all the coviarates
    data = cov_dis, # Only fit on time values
    family = dist, # Negative binomial family
    epsilon = ep
  )

  # calculate intercept-only models
  model.glm.0 <- glm(gene.i.count ~ 1, # Formula with just intercept
    family = dist, # Negative binomial family
    epsilon = ep
  )

  # Test if the full model is significant
  test <- anova(model.glm.0, model.glm, test = "Chisq")

  # If the p-value is extreme then set it to one
  if (is.na(test[["Pr(>Chi)"]][2])) {
    test[["Pr(>Chi)"]][[2]] <- 1
  }

  # Set the p-value
  p.value <- test[["Pr(>Chi)"]][2]

  # Store everything in a list
  return(list(
    full.model = model.glm,
    intercept.model = model.glm.0,
    anova.res = test,
    p.value = p.value
  ))
}
