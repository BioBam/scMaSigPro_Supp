library(discretization)


data(iris)


disc <- chiM(iris, alpha = 0.05)
