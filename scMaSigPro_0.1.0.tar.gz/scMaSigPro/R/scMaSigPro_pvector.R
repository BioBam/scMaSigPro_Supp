#' pvector_scMASigPro
#'
#' @name pvector_scMASigPro
#' @aliases pvector_scMASigPro
#'
#' @param scMaSigPro.obj Description of Slot
#' @param Q Description of Slot
#' @param min.obs Description of Slot
#' @param dist.family Description of Slot
#' @param padjust Description of Slot
#' @param assay.name Description of Slot
#' @param MT.adjust Correct
#' @param ep Epsilon
#' @param nb.k Dispersion factor negative binomial
#'

pvector_scMASigPro <- function(scMaSigPro.obj, # Expected Single Cell Count Table
                               Q = 0.05, # significance level
                               MT.adjust = "BH", # Depends on library(stats) p.adjust
                               min.obs = 6, # Minimum expression Value of Gene Required
                               dist.family = "nb", # Family of distribution
                               assay.name = "counts",
                               ep = 0.00001,
                               nb.k = NULL) {
  # Accepted-Family Vector
  accpt.fam <- c("g", "nb", "zinb", "p", "zip", "zap", "zanb", "gp", "gnb")
  count.na <- function(x) (length(x) - length(x[is.na(x)]))

  # Check if the supplied family is correct
  if (!is.element(dist.family, accpt.fam)) {
    stop("Please select one of the accepted family")
  }

  # Required packages to work
  set.seed(2022)

  # Covariate
  covariate <- as.data.frame(scMaSigPro.obj@covariate@covariate)

  # Extract Counts
  p.counts <- scMaSigPro.obj@assays@data@listData[[assay.name]]
  p.counts <- p.counts[apply(p.counts, 1, count.na) >= min.obs, ]

  # Calculate Total sum
  # Drop genes if total sum is 0
  sum.tot <- apply(p.counts, 1, sum)
  p.counts.0 <- which(sum.tot == 0)
  if (length(p.counts.0) > 0) {
    p.counts <- p.counts[-p.counts.0, ]
  }

  # Create a vector of genes
  gene.name.vector <- rownames(p.counts)

  # return(list(y = as.numeric(p.counts[rownames(p.counts) %in% gene.name.vector[1], ]),x = covariate))

  # Apply lapply function
  computed_models <- lapply(gene.name.vector, function(gene.i, USE.NAMES = TRUE,
                                                       count_data = p.counts,
                                                       cov_dis = covariate,
                                                       dist_family = dist.family,
                                                       epsilon = ep, nb_k = nb.k) {
    # Invoke tests nd modelGLm as Null
    test <- model.glm.0 <- NULL

    # Extract the counts of the gene
    gene.i.count <- as.numeric(count_data[rownames(count_data) %in% gene.i, ])

    if (dist_family %in% c("g", "nb", "p")) {
      if (is.null(nb_k) == TRUE) {
        nb_k <- 10
      }

      # Compute using Stat glm()
        #source("stat_glm.R")
      #return(compute_stat_glm_test(
        return(compute_stat_glm(
        dist_family = dist_family,
        gene.i.count = gene.i.count,
        cov_dis = cov_dis,
        ep = epsilon, nb_k = nb_k
      ))
    } else if (dist_family %in% c("zinb", "zip", "gp", "gnb")) {
      print(colnames(cov_dis)[1])

      fr <- formula(paste0("gene.i.count", "~", paste(colnames(cov_dis), collapse = "+")))

      stop()
      full.model <- glmmTMB(
        formula = fr,
        ziformula = ~.,
        data = cov_dis,
        family = "genpois"
      )

      stop()
      # print(summary(full.model))
      intercept.model <- glmmTMB(gene.i.count ~ 1,
        ziformula = ~1,
        data = cov_dis,
        family = "nbinom2"
      )
      test <- anova(intercept.model, full.model)

      print(test)
      # print(summary(intercept.model))
      stop()
    } else {
      stop("Please select one of the available distributions.")
    }
    gc()
  })

  # Return a named list
  names(computed_models) <- gene.name.vector

  # P-value adjustment
  p_value_vector <- lapply(computed_models, FUN = function(gene.i.model, USE.NAMES = TRUE) {
    return(gene.i.model[["anova.res"]][["Pr(>Chi)"]][[2]])
  })

  # Rename Vector
  names(p_value_vector) <- names(computed_models)

  # Unlist
  p_value_vector <- c(unlist(p_value_vector))

  # p-Value correction
  p.adj_value_vector <- p.adjust(p_value_vector, # Supply p value vector after for all the models
    method = MT.adjust, # Method for p-value correction
    n = length(p_value_vector)
  )

  # Extract the Full models
  full.model.list <- lapply(computed_models, FUN = function(gene.i.model, USE.NAMES = TRUE) {
    return(gene.i.model[["full.model"]])
  })
  names(full.model.list) <- names(computed_models)

  # Intercept models
  intercept.model.list <- lapply(computed_models, FUN = function(gene.i.model, USE.NAMES = TRUE) {
    return(gene.i.model[["intercept.model"]])
  })
  names(intercept.model.list) <- names(computed_models)

  # Test Results
  anova.res.list <- lapply(computed_models, FUN = function(gene.i.model, USE.NAMES = TRUE) {
    return(gene.i.model[["anova.res"]])
  })
  names(intercept.model.list) <- names(computed_models)

  pVector.obj <- new("pVectorClass",
    full.models = full.model.list,
    intercept.models = intercept.model.list,
    test.res = anova.res.list,
    p.value = p_value_vector,
    adj.p.value = p.adj_value_vector
  )

  # Update Significance
  scMaSigPro.obj@parameters@sig.level <- Q

  scMaSigPro.obj@pVector <- pVector.obj

  return(scMaSigPro.obj)
}
