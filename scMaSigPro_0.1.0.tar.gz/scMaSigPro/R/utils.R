count.na <- function(x) {
  return(length(x) - length(x[is.na(x)]))
}
