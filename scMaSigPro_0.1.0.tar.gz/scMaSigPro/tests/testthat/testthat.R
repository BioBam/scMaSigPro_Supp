# This file is part of the standard setup for testthat.
# It is recommended that you do not modify it.
#
# Where should you do additional test configuration?
# Learn more about the roles of various files in:
# * https://r-pkgs.org/tests.html
# * https://testthat.r-lib.org/reference/test_package.html#special-files

library(testthat)
library(scMaSigPro)
library(maSigPro)

# Load the Data
data_file <- system.file("extdata", "sce.test.RDS", package = "scMaSigPro")
data <- readRDS(data_file)

test_check("Check_P_Vector_P_Values.R")

# Test cases go here
test_that("Loading the SCE Object correctly", {
    # Define two vectors
    vec1 <- c(1, 2, 3, 4, 5)
    vec2 <- c(1, 2, 3, 4, 5)

    # First, check that the vectors have the same length
    expect_equal(length(vec1), length(vec2))

    # Next, check that all elements in the vectors are the same
    expect_equal(vec1, vec2)


})
