test_that("P. Vector P Values Match", {

    library(maSigPro)
    sce.test <- readRDS("testthat/sce.test.RDS")

})
